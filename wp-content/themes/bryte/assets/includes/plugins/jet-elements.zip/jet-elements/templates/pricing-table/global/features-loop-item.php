<?php
/**
 * Features list item template
 */

$classes  = 'pricing-feature-' . $this->__loop_item( array( '_id' ) );
$classes .= ' ' . $this->__loop_item( array( 'item_included' ) );

?>
<div class="pricing-feature <?php echo $classes; ?>">
	<div class="pricing-feature__inner"><?php
		echo $this->__loop_item( array( 'item_text' ) );
	?></div>
</div>