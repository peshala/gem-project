<?php
/**
 * Posts loop start template
 */
?>
<div class="jet-posts col-row <?php echo jet_elements_tools()->gap_classes( $this->get_attr( 'columns_gap' ), $this->get_attr( 'rows_gap' ) ); ?>">