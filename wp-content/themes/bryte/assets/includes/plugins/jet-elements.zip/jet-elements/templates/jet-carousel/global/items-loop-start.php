<?php
/**
 * Loop start template
 */
$settings = $this->get_settings();

$options = array(
	'slidesToShow'   => array(
		'desktop' => absint( $settings['slides_to_show'] ),
		'tablet'  => 0,
		'laptop'  => 0,
	),
	'autoplaySpeed'  => absint( $settings['autoplay_speed'] ),
	'autoplay'       => filter_var( $settings['autoplay'], FILTER_VALIDATE_BOOLEAN ),
	'infinite'       => filter_var( $settings['infinite'], FILTER_VALIDATE_BOOLEAN ),
	'pauseOnHover'   => filter_var( $settings['pause_on_hover'], FILTER_VALIDATE_BOOLEAN ),
	'speed'          => absint( $settings['speed'] ),
	'arrows'         => filter_var( $settings['arrows'], FILTER_VALIDATE_BOOLEAN ),
	'dots'           => filter_var( $settings['dots'], FILTER_VALIDATE_BOOLEAN ),
	'slidesToScroll' => absint( $settings['slides_to_scroll'] ),
);

if ( 1 === absint( $settings['slides_to_show'] ) ) {
	$options['fade'] = ( 'fade' === $settings['effect'] );
}

?>
<div class="adv-carousel jet-carousel elementor-slick-slider" data-slider_options='<?php echo json_encode( $options ); ?>'>