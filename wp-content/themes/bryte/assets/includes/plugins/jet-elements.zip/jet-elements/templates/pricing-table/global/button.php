<?php
/**
 * Pricing table action button
 */
?>
<a class="button pricing-table-button" href="<?php echo $this->__html( 'button_url' ); ?>"><?php
	echo $this->__html( 'button_text' );
?></a>